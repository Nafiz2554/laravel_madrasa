
<?php $__env->startSection('admin_content'); ?>
    <div class="dashboard-wrapper">
        <div class="dashboard-ecommerce">
            <div class="container-fluid dashboard-content ">
                <!-- ============================================================== -->
                <!-- pageheader  -->
                <!-- ============================================================== -->
                <div class="row">
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                        <div class="page-header">
                            <h2 class="pageheader-title"> আল-জামিয়াতুল আরাবিয়া লিল বানাত হযরত ফাতেমা রাযিঃ চকলোকমান মহিলা
                                মাদ্রাসা (ও এতিম খানা)</h2>
                            <p class="pageheader-text">Nulla euismod urna eros, sit amet scelerisque torton lectus vel mauris
                                facilisis faucibus at enim quis massa lobortis rutrum.</p>
                            <div class="page-breadcrumb">
                                <nav aria-label="breadcrumb">
                                    <ol class="breadcrumb">
                                        <li class="breadcrumb-item"><a href="#" class="breadcrumb-link">Dashboard</a>
                                        </li>
                                        <li class="breadcrumb-item active" aria-current="page">চকলোকমান মহিলা মাদ্রাসা</li>
                                    </ol>
                                </nav>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- ============================================================== -->
                <!-- end pageheader  -->
                <!-- ============================================================== -->
                <div class="offset-xl-1 col-xl-10">
                    <div class="row">
                        <div class="col-xl-12 col-lg-12 col-md-6 col-sm-12 col-12">
                            <div class="section-block">
                                <h5 style="color: maroon;" class="text-center p-2">All Admitted Student Lists:</h5>
                            </div>
                        </div>
                        <?php $__currentLoopData = $admissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $admission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-xl-4 col-lg-4 col-md-6 col-sm-12 col-12">
                                <div class="card">
                                    <div class="card-header bg-primary text-center p-3 ">
                                        <a target="_blank" href="<?php echo e(url('view-student-profile/' . $admission->studentname)); ?>">
                                            <h4 class="mb-0 text-white"> <i class="fa fa-eye"></i> View</h4>
                                        </a>
                                    </div>
                                    <div class="card-body text-center">
                                        <h4 class="mb-1"><?php echo e($admission->studentname); ?></h4>
                                        <p><?php echo e($admission->mobile); ?></p>
                                    </div>
                                    <div class="card-body border-top">
                                        <ul class="list-unstyled bullet-check font-14">
                                            <li>Class: <?php echo e($admission->class); ?></li>
                                            <li>Section: <?php echo e($admission->jamat); ?></li>

                                        </ul>
                                        <a target="_blank" href="<?php echo e(url('view-student-profile/' . $admission->studentname)); ?>" class="btn btn-outline-secondary btn-block btn-lg">Deposits</a>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>




                    </div>
                </div>



            </div>
        </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel\madrasa\madrasa\resources\views/admin/student.blade.php ENDPATH**/ ?>
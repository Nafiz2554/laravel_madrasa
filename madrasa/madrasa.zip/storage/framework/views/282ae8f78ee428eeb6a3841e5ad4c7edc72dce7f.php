
<?php $__env->startSection('admin_content'); ?>
    <div class="dashboard-wrapper">
        <div class="container-fluid  dashboard-content">
            <div class="row">
                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 text-center">
                    <div class="page-header">
                        <h2 style="color: maroon; font-weight:bold;" class="pageheader-title">সকল জমা দেখুন</h2>

                    </div>
                </div>
                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 text-right">
                    <div class="page-header">
                        <ul style="list-style-type: none;">
                            <li style="color: rgb(0, 51, 128); font-weight:bold;"><i class="fa fa-arrow-right"
                                    aria-hidden="true"></i> সাধারণ ফান্ড</li>
                            <li style="color: rgb(4, 128, 0); font-weight:bold;"><i class="fa fa-arrow-right"
                                    aria-hidden="true"></i> লিল্লাহ্ ফান্ড</li>
                        </ul>

                    </div>
                </div>
            </div>

            <div class="row">
                <!-- ============================================================== -->
                <!-- data table rowgroup  -->
                <!-- ============================================================== -->
                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                    <div class="card">
                        <div class="card-body">
                            <p class="alert-warning text-center">
                                <?php
                                $message = Session()->get('message');
                                if ($message) {
                                    echo $message;
                                    Session()->put('message', null);
                                }
                                ?>
                            </p>
                            <div class="table-responsive">
                                <table id="example2" class="table table-striped table-bordered" style="width:100%">
                                    <thead>
                                        <tr>
                                            <th class="text-center"><b>ক্রমিক নং</b></th>
                                            <th><b>তারিখ</b></th> 
                                            <th><b>জমাদানকারীর নাম</b></th>
                                            <th><b>পেশা</b></th>
                                            <th><b>মোবাইল নং</b></th>
                                            <th><b>ঠিকানা</b></th>
                                            <th><b>সন</b></th>
                                            <th style="color: rgb(0, 51, 128);">রশিদবহি/পাতানং</th>
                                            <th style="color: rgb(0, 51, 128);">খোরাকী</th>
                                            <th style="color: rgb(0, 51, 128);">দান ও উন্নয়ন</th>
                                            <th style="color: rgb(0, 51, 128);">ভর্তি ফি</th>
                                            <th style="color: rgb(0, 51, 128);">মাসিক চাঁদা</th>
                                            <th style="color: rgb(0, 51, 128);">বাড়ি/দোকানভাড়া</th>
                                            <th style="color: rgb(0, 51, 128);">পরীক্ষার ফি</th>
                                            <th style="color: rgb(0, 51, 128);">সাধারণ কর্জগ্রহণ</th>
                                            <th style="color: rgb(4, 128, 0);">যাকাত/ফেৎরা/কোরবানীর চামড়া/ছদকা/মান্নত</th>
                                            <th style="color: rgb(4, 128, 0);">লিল্লাহ্ কর্জগ্রহণ</th>
                                            <th><b>উভয়ফান্ডের মোটজমা</b></th>
                                            <th>মানি রিসিপ্ট</th>
                                            <th>এডিট</th>
                                            <th>ডিলিট</th>
                                        </tr>
                                    </thead>
                                    <?php $__currentLoopData = $deposits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $deposit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tbody>
                                            <tr>
                                                <td><?php echo e($loop->index+1); ?></td>
                                                <td><?php echo e($deposit->date); ?></td> 
                                                <td><?php echo e($deposit->name); ?></td>
                                                <td><?php echo e($deposit->occupation); ?></td>
                                                <td><?php echo e($deposit->mobile); ?></td>
                                                <td><?php echo e($deposit->address); ?></td>
                                                <td><?php echo e($deposit->year); ?></td>
                                                <td><?php echo e($deposit->patano); ?></td>
                                                <td><?php echo e($deposit->khoraki); ?> </td>
                                                <td><?php echo e($deposit->dan); ?> </td>
                                                <td><?php echo e($deposit->vortifee); ?> </td>
                                                <td><?php echo e($deposit->masikcada); ?> </td>
                                                <td><?php echo e($deposit->baridokan); ?> </td>
                                                <td><?php echo e($deposit->examfee); ?> </td>
                                                <td><?php echo e($deposit->generalfee); ?> </td>
                                                <td><?php echo e($deposit->jakat); ?> </td>
                                                <td><?php echo e($deposit->lillahfee); ?> </td>
                                                <td><?php echo e($deposit->total); ?> /- Taka</td>
                                                <td><a target="_blank"
                                                        href="<?php echo e(url('deposit-money-recipt/' . $deposit->id)); ?>"
                                                        class="btn btn-primary"><i class="fa fa-print"></i></a></td>
                                                <td><button type="button" data-bs-toggle="modal"
                                                        data-bs-target="#exampleModal<?php echo e($deposit->id); ?>"
                                                        class="btn btn-warning"><i class="fa fa-edit"></i></button>
                                                </td>
                                                <td>
                                                    <form action="<?php echo e(url('/deposit-delete/' . $deposit->id)); ?>"
                                                        method="post">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('DELETE'); ?>
                                                        <button class="btn btn-danger" type="submit">
                                                            <i class="fa fa-trash"></i>
                                                        </button>
                                                    </form>
                                                </td>
                                            </tr>

                                        </tbody>
                                        <!-- Modal -->
                                        <div class="modal fade" id="exampleModal<?php echo e($deposit->id); ?>" tabindex="-1"
                                            aria-labelledby="exampleModalLabel<?php echo e($deposit->id); ?>" aria-hidden="true">
                                            <div class="modal-dialog">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="exampleModal<?php echo e($deposit->id); ?>">
                                                            Edit This Deposit Informations</h5>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                            aria-label="Close"></button>
                                                    </div>
                                                    <div class="modal-body">

                                                        <form action="<?php echo e(url('/update-deposit/' . $deposit->id)); ?>"
                                                            method="post" enctype="multipart/form-data">
                                                            <?php echo csrf_field(); ?>
                                                            <div class="row">
                                                                <div class="col-md-6">
                                                                    <div class="form-group">
                                                                        <label>তারিখ:</label>
                                                                        <input type="date" class="form-control"
                                                                            name="date"
                                                                            value="<?php echo e($deposit->date); ?>">
                                                                    </div>
                                                                    <div class="form-group">
                                                                        <label>মাসের নাম:</label>
                                                                        <input type="month" class="form-control"
                                                                            name="month"
                                                                            value="<?php echo e($deposit->month); ?>">
                                                                    </div>
                                                                    <div class="form-group">
                                                                        <label>সন:</label>
                                                                        <input type="text" class="form-control"
                                                                            name="year"
                                                                            value="<?php echo e($deposit->year); ?>">
                                                                    </div>
                                                                    <div class="form-group">
                                                                        <label>জমাদানকারীর নাম:</label>
                                                                        <input type="text" class="form-control"
                                                                            name="name"
                                                                            value="<?php echo e($deposit->name); ?>">
                                                                    </div>
                                                                    <div class="form-group">
                                                                        <label>পেশা:</label>
                                                                        <input type="text" class="form-control"
                                                                            name="occupation"
                                                                            value="<?php echo e($deposit->occupation); ?>">
                                                                    </div>
                                                                    <div class="form-group">
                                                                        <label>মোবাইল নং:</label>
                                                                        <input type="text" class="form-control"
                                                                            name="mobile" value="<?php echo e($deposit->mobile); ?>">
                                                                    </div>
                                                                    <div class="form-group">
                                                                        <label>ঠিকানা:</label>
                                                                        <input type="text" class="form-control"
                                                                            name="address"
                                                                            value="<?php echo e($deposit->address); ?>">
                                                                    </div>
                                                                    <div class="form-group">
                                                                        <label>রশিদ বহি ও পাতা নং:</label>
                                                                        <input type="text" class="form-control"
                                                                            name="patano"
                                                                            value="<?php echo e($deposit->patano); ?>">
                                                                    </div>
                                                                    <div class="form-group">
                                                                        <label>খোরাকী:</label>
                                                                        <input type="text" class="form-control"
                                                                            name="khoraki"
                                                                            value="<?php echo e($deposit->khoraki); ?>">
                                                                    </div>
                                                                     

                                                                </div>
                                                                <div class="col-md-6">

                                                                    <div class="form-group">
                                                                        <label>দান ও উন্নয়ন:</label>
                                                                        <input type="text" class="form-control"
                                                                            name="dan"
                                                                            value="<?php echo e($deposit->dan); ?>">
                                                                    </div>
                                                                    <div class="form-group">
                                                                        <label>ভর্তি ফি:</label>
                                                                        <input type="text" class="form-control"
                                                                            name="vortifee"
                                                                            value="<?php echo e($deposit->vortifee); ?>">
                                                                    </div>

                                                                    <div class="form-group">
                                                                        <label>মাসিক চাঁদা:</label>
                                                                        <input type="text" class="form-control"
                                                                            name="masikcada"
                                                                            value="<?php echo e($deposit->masikcada); ?>">
                                                                    </div>
                                                                    <div class="form-group">
                                                                        <label>বাড়ি / দোকানভাড়া:</label>
                                                                        <input type="text" class="form-control"
                                                                            name="baridokan"
                                                                            value="<?php echo e($deposit->baridokan); ?>">
                                                                    </div>

                                                                    <div class="form-group">
                                                                        <label>পরীক্ষার ফি:</label>
                                                                        <input type="text" class="form-control"
                                                                            name="examfee"
                                                                            value="<?php echo e($deposit->examfee); ?>">
                                                                    </div>
                                                                    <div class="form-group">
                                                                        <label>সাধারণ কর্জ গ্রহণ:</label>
                                                                        <input type="text" class="form-control"
                                                                            name="generalfee"
                                                                            value="<?php echo e($deposit->generalfee); ?>">
                                                                    </div>
                                                                    <div class="form-group">
                                                                        <label>যাকাত/ ফেৎরা/ কোরবানীর চামড়া/ ছদকা/ মান্নত:</label>
                                                                        <input type="text" class="form-control"
                                                                            name="jakat"
                                                                            value="<?php echo e($deposit->jakat); ?>">
                                                                    </div>
                                                                    <div class="form-group">
                                                                        <label>লিল্লাহ্ কর্জ গ্রহণ:</label>
                                                                        <input type="text" class="form-control"
                                                                            name="lillahfee"
                                                                            value="<?php echo e($deposit->lillahfee); ?>">
                                                                    </div>
                                                                     
                                                                </div>
                                                            </div>
                                                            <div class="text-end mt-4">
                                                                <button type="submit"
                                                                    class="btn btn-primary">Edit</button>
                                                            </div>
                                                        </form>

                                                    </div>

                                                </div>
                                            </div>
                                        </div>

                                        
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- ============================================================== -->
                <!-- end data table rowgroup  -->
                <!-- ============================================================== -->
            </div>
            <div class="footer">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">
                            Copyright © 2022, চকলোকমান মহিলা মাদ্রাসা. All rights reserved. Developed by <a
                                href=" ">RoyalSoft</a>.
                        </div>
                        <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">
                            <div class="text-md-right footer-links d-none d-sm-block">
                                <a href="javascript: void(0);">Dashboard</a>
                                <a href="javascript: void(0);">Support</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>


        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel\madrasa\madrasa\resources\views/admin/deposit/index.blade.php ENDPATH**/ ?>
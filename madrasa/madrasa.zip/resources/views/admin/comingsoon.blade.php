@extends('admin.admin_master')
@section('admin_content')
    <div class="dashboard-wrapper">
        <div class="container-fluid dashboard-content">
            <div class="row">
                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                    <h3 style="color: maroon;" class="text-center">This Page is Coming Soon!</h3>
                </div>
            </div>
        </div>

    </div>
@endsection
